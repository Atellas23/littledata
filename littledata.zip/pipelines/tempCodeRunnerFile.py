for csv_file in csv_files:
#     data = csv_file.mapValues(lambda v: v.split(
#         '\n')).filter(lambda t: 'date' not in t[0])
#     print(data.first())
#     break